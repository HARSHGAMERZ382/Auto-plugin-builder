package com.ghostie.autopluginbuilder;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class AutoPluginBuilder extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("AutoPluginBuilder enabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("builder")) {
            sender.sendMessage(ChatColor.AQUA + "[AutoPluginBuilder] "
                    + ChatColor.GREEN + "Plugin is working!");
            return true;
        }
        return false;
    }
}
