# Auto Plugin Builder

A starter Paper plugin project that builds a downloadable JAR with GitHub Actions.

## Build
1. Upload the files in this project to the root of your GitHub repository.
2. Open the **Actions** tab.
3. Select **Build Minecraft Plugin** and run the workflow, or push a commit to `main`.
4. Open the completed workflow run and download the `AutoPluginBuilder-JAR` artifact.
5. Put the downloaded JAR in your Paper server's `plugins` folder and restart the server.

## Test command
Run `/builder` in-game. The plugin responds that it is working.

## Compatibility
This starter targets Paper API 1.21.4 and Java 21. It is not guaranteed to work on every Minecraft version or on every server platform.
